create function proc_kiem_tra_dieu_kien_dang_ky(p_ma_kh character varying, p_ma_dv character varying, OUT p_can_dang_ky integer, OUT p_ly_do text) returns record
    language plpgsql
as
$$
DECLARE
    v_count INTEGER;
    v_loai_dv VARCHAR(20);
    v_ma_bm VARCHAR(10);
BEGIN
    SELECT COUNT(*) INTO v_count FROM KHACHHANG WHERE MaKH = p_ma_kh;
    IF v_count = 0 THEN
        p_can_dang_ky := 0;
        p_ly_do := 'Khách hàng không tồn tại';
        RETURN;
    END IF;

    SELECT COUNT(*), MAX(LoaiDV), MAX(MaBM) INTO v_count, v_loai_dv, v_ma_bm
    FROM DICHVU WHERE MaDV = p_ma_dv;
    IF v_count = 0 THEN
        p_can_dang_ky := 0;
        p_ly_do := 'Dịch vụ không tồn tại';
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_count FROM CT_DKDV ct
    JOIN HOADON hd ON ct.MaHD = hd.MaHD
    WHERE hd.MaKH = p_ma_kh AND ct.MaDV = p_ma_dv AND hd.TrangThai = 'DaThanhToan';
    IF v_count > 0 THEN
        p_can_dang_ky := 0;
        p_ly_do := 'Đã đăng ký dịch vụ này rồi';
        RETURN;
    END IF;

    IF v_loai_dv != 'TuDo' THEN
        SELECT COUNT(*) INTO v_count FROM LOP
        WHERE MaBM = v_ma_bm AND TinhTrang = 'ChuaDay';
        IF v_count = 0 THEN
            p_can_dang_ky := 0;
            p_ly_do := 'Không còn lớp trống cho bộ môn này';
            RETURN;
        END IF;
    END IF;

    p_can_dang_ky := 1;
    p_ly_do := 'Có thể đăng ký';
EXCEPTION
    WHEN OTHERS THEN
        p_can_dang_ky := 0;
        p_ly_do := 'Lỗi hệ thống: ' || SQLERRM;
END;
$$;

alter function proc_kiem_tra_dieu_kien_dang_ky(varchar, varchar, out integer, out text) owner to qlyphonggym;

