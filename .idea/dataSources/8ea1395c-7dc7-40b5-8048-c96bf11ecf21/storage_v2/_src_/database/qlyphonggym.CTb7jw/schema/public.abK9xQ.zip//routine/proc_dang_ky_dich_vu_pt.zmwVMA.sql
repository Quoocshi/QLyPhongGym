create function proc_dang_ky_dich_vu_pt(p_ma_kh character varying, p_ma_dv character varying, p_ma_trainer character varying, OUT p_ma_hd character varying, OUT p_ma_ctdk character varying, OUT p_result character varying, OUT p_error_msg text) returns record
    language plpgsql
as
$$
DECLARE
    v_don_gia NUMERIC;
    v_thoi_han INTEGER;
    v_loai_dv VARCHAR(20);
    v_ma_bm VARCHAR(10);
    v_max_hd_number INTEGER;
    v_max_ctdk_number INTEGER;
    v_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_count FROM KHACHHANG WHERE MaKH = p_ma_kh;
    IF v_count = 0 THEN
        p_result := 'ERROR';
        p_error_msg := 'Không tìm thấy khách hàng: ' || p_ma_kh;
        RETURN;
    END IF;

    SELECT COUNT(*), MAX(DonGia), MAX(ThoiHan), MAX(LoaiDV), MAX(MaBM)
    INTO v_count, v_don_gia, v_thoi_han, v_loai_dv, v_ma_bm
    FROM DICHVU WHERE MaDV = p_ma_dv;

    IF v_count = 0 THEN
        p_result := 'ERROR';
        p_error_msg := 'Không tìm thấy dịch vụ: ' || p_ma_dv;
        RETURN;
    END IF;

    IF v_loai_dv != 'PT' THEN
        p_result := 'ERROR';
        p_error_msg := 'Dịch vụ không phải loại PT: ' || p_ma_dv;
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_count FROM NHANVIEN
    WHERE MaNV = p_ma_trainer AND LoaiNV = 'Trainer';
    IF v_count = 0 THEN
        p_result := 'ERROR';
        p_error_msg := 'Không tìm thấy trainer: ' || p_ma_trainer;
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_count FROM CT_CHUYENMON cm
    WHERE cm.MaNV = p_ma_trainer AND cm.MaBM = v_ma_bm;
    IF v_count = 0 THEN
        p_result := 'ERROR';
        p_error_msg := 'Trainer không có chuyên môn phù hợp';
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_count FROM CT_DKDV ct
    JOIN HOADON hd ON ct.MaHD = hd.MaHD
    WHERE hd.MaKH = p_ma_kh AND ct.MaDV = p_ma_dv AND hd.TrangThai = 'DaThanhToan';
    IF v_count > 0 THEN
        p_result := 'ERROR';
        p_error_msg := 'Khách hàng đã đăng ký dịch vụ này rồi';
        RETURN;
    END IF;

    SELECT COALESCE(MAX(SUBSTRING(MaHD FROM 3)::INTEGER), 0) + 1
    INTO v_max_hd_number FROM HOADON WHERE MaHD LIKE 'HD%';
    p_ma_hd := 'HD' || LPAD(v_max_hd_number::TEXT, 3, '0');

    INSERT INTO HOADON (MaHD, MaKH, NgayLap, TrangThai, TongTien)
    VALUES (p_ma_hd, p_ma_kh, CURRENT_TIMESTAMP, 'ChuaThanhToan', v_don_gia);

    SELECT COALESCE(MAX(SUBSTRING(MaCTDK FROM 3)::INTEGER), 0) + 1
    INTO v_max_ctdk_number FROM CT_DKDV WHERE MaCTDK LIKE 'CT%';
    p_ma_ctdk := 'CT' || LPAD(v_max_ctdk_number::TEXT, 3, '0');

    INSERT INTO CT_DKDV (MaCTDK, MaHD, MaDV, NgayBD, NgayKT, MaLop, MaNV)
    VALUES (p_ma_ctdk, p_ma_hd, p_ma_dv, CURRENT_TIMESTAMP,
            CURRENT_TIMESTAMP + (v_thoi_han || ' days')::INTERVAL, NULL, p_ma_trainer);

    p_result := 'SUCCESS';
    p_error_msg := NULL;
EXCEPTION
    WHEN OTHERS THEN
        p_result := 'ERROR';
        p_error_msg := 'Lỗi hệ thống: ' || SQLERRM;
END;
$$;

alter function proc_dang_ky_dich_vu_pt(varchar, varchar, varchar, out varchar, out varchar, out varchar, out text) owner to qlyphonggym;

