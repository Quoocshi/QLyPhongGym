create function proc_dang_ky_dich_vu_universal(p_ma_kh character varying, p_list_ma_dv text, p_list_trainer_id text DEFAULT NULL::text, p_list_class_id text DEFAULT NULL::text, OUT p_ma_hd character varying, OUT p_tong_tien numeric, OUT p_result character varying, OUT p_error_msg text) returns record
    language plpgsql
as
$$
DECLARE
    v_ma_hd VARCHAR(10);
    v_tong_tien NUMERIC := 0;
    v_ma_ctdk VARCHAR(10);
    v_ma_dv VARCHAR(10);
    v_trainer_id VARCHAR(10);
    v_class_id VARCHAR(10);
    v_don_gia NUMERIC;
    v_thoi_han INTEGER;
    v_loai_dv VARCHAR(20);
    v_ma_bm VARCHAR(10);
    v_ma_lop VARCHAR(10);
    v_ma_nv VARCHAR(10);
    v_dv_array TEXT[];
    v_trainer_array TEXT[];
    v_class_array TEXT[];
    v_service_index INTEGER := 1;
    v_max_hd_number INTEGER;
    v_current_ctdk_number INTEGER;
    v_count INTEGER;
    v_retry_count INTEGER := 0;
    v_max_retries INTEGER := 3;
BEGIN
    WHILE v_retry_count <= v_max_retries LOOP
        BEGIN
            SELECT COUNT(*) INTO v_count FROM KHACHHANG WHERE MaKH = p_ma_kh;
            IF v_count = 0 THEN
                p_result := 'ERROR';
                p_error_msg := 'Không tìm thấy khách hàng: ' || p_ma_kh;
                RETURN;
            END IF;

            SELECT COALESCE(MAX(SUBSTRING(MaHD FROM 3)::INTEGER), 0) + 1
            INTO v_max_hd_number FROM HOADON WHERE MaHD LIKE 'HD%';
            v_ma_hd := 'HD' || LPAD(v_max_hd_number::TEXT, 3, '0');

            LOOP
                SELECT COUNT(*) INTO v_count FROM HOADON WHERE MaHD = v_ma_hd;
                EXIT WHEN v_count = 0;
                v_max_hd_number := v_max_hd_number + 1;
                v_ma_hd := 'HD' || LPAD(v_max_hd_number::TEXT, 3, '0');
            END LOOP;

            INSERT INTO HOADON (MaHD, MaKH, NgayLap, TrangThai, TongTien)
            VALUES (v_ma_hd, p_ma_kh, CURRENT_TIMESTAMP, 'ChuaThanhToan', 0);

            v_dv_array := string_to_array(p_list_ma_dv, ',');
            v_trainer_array := string_to_array(COALESCE(p_list_trainer_id, ''), ',');
            v_class_array := string_to_array(COALESCE(p_list_class_id, ''), ',');

            FOR v_service_index IN 1..array_length(v_dv_array, 1) LOOP
                v_ma_dv := TRIM(v_dv_array[v_service_index]);

                IF LENGTH(v_ma_dv) > 0 THEN
                    IF v_service_index <= array_length(v_trainer_array, 1) THEN
                        v_trainer_id := NULLIF(TRIM(v_trainer_array[v_service_index]), '');
                        IF v_trainer_id = 'null' THEN v_trainer_id := NULL; END IF;
                    ELSE
                        v_trainer_id := NULL;
                    END IF;

                    IF v_service_index <= array_length(v_class_array, 1) THEN
                        v_class_id := NULLIF(TRIM(v_class_array[v_service_index]), '');
                        IF v_class_id = 'null' THEN v_class_id := NULL; END IF;
                    ELSE
                        v_class_id := NULL;
                    END IF;

                    SELECT COUNT(*), MAX(DonGia), MAX(ThoiHan), MAX(LoaiDV), MAX(MaBM)
                    INTO v_count, v_don_gia, v_thoi_han, v_loai_dv, v_ma_bm
                    FROM DICHVU WHERE MaDV = v_ma_dv;

                    IF v_count = 0 THEN
                        p_result := 'ERROR';
                        p_error_msg := 'Không tìm thấy dịch vụ: ' || v_ma_dv;
                        RETURN;
                    END IF;

                    SELECT COUNT(*) INTO v_count FROM CT_DKDV ct
                    JOIN HOADON hd ON ct.MaHD = hd.MaHD
                    WHERE hd.MaKH = p_ma_kh AND ct.MaDV = v_ma_dv AND hd.TrangThai = 'DaThanhToan';

                    IF v_count > 0 THEN
                        p_result := 'ERROR';
                        p_error_msg := 'Khách hàng đã đăng ký dịch vụ: ' || v_ma_dv;
                        RETURN;
                    END IF;

                    SELECT COALESCE(MAX(SUBSTRING(MaCTDK FROM 3)::INTEGER), 0) + 1
                    INTO v_current_ctdk_number FROM CT_DKDV WHERE MaCTDK LIKE 'CT%';
                    v_ma_ctdk := 'CT' || LPAD(v_current_ctdk_number::TEXT, 3, '0');

                    LOOP
                        SELECT COUNT(*) INTO v_count FROM CT_DKDV WHERE MaCTDK = v_ma_ctdk;
                        EXIT WHEN v_count = 0;
                        v_current_ctdk_number := v_current_ctdk_number + 1;
                        v_ma_ctdk := 'CT' || LPAD(v_current_ctdk_number::TEXT, 3, '0');
                    END LOOP;

                    v_ma_lop := NULL;
                    v_ma_nv := NULL;

                    IF v_loai_dv = 'PT' THEN
                        IF v_trainer_id IS NOT NULL THEN
                            SELECT COUNT(*) INTO v_count FROM NHANVIEN
                            WHERE MaNV = v_trainer_id AND LoaiNV = 'Trainer';

                            IF v_count = 0 THEN
                                p_result := 'ERROR';
                                p_error_msg := 'Không tìm thấy trainer: ' || v_trainer_id;
                                RETURN;
                            END IF;

                            SELECT COUNT(*) INTO v_count FROM CT_CHUYENMON cm
                            WHERE cm.MaNV = v_trainer_id AND cm.MaBM = v_ma_bm;

                            IF v_count = 0 THEN
                                p_result := 'ERROR';
                                p_error_msg := 'Trainer ' || v_trainer_id || ' không có chuyên môn phù hợp';
                                RETURN;
                            END IF;

                            v_ma_nv := v_trainer_id;
                        ELSE
                            SELECT nv.MaNV INTO v_ma_nv FROM NHANVIEN nv
                            JOIN CT_CHUYENMON cm ON nv.MaNV = cm.MaNV
                            WHERE nv.LoaiNV = 'Trainer' AND cm.MaBM = v_ma_bm
                            ORDER BY nv.MaNV LIMIT 1;

                            IF v_ma_nv IS NULL THEN
                                p_result := 'ERROR';
                                p_error_msg := 'Không tìm thấy trainer phù hợp cho bộ môn: ' || v_ma_bm;
                                RETURN;
                            END IF;
                        END IF;

                    ELSIF v_loai_dv = 'Lop' THEN
                        IF v_class_id IS NOT NULL THEN
                            SELECT COUNT(*), MAX(MaNV) INTO v_count, v_ma_nv FROM LOP
                            WHERE MaLop = v_class_id AND MaBM = v_ma_bm AND TinhTrang = 'ChuaDay';

                            IF v_count = 0 THEN
                                SELECT COUNT(*) INTO v_count FROM LOP WHERE MaLop = v_class_id;
                                p_result := 'ERROR';
                                IF v_count = 0 THEN
                                    p_error_msg := 'Không tìm thấy lớp: ' || v_class_id;
                                ELSE
                                    p_error_msg := 'Lớp ' || v_class_id || ' không phù hợp hoặc đã đầy';
                                END IF;
                                RETURN;
                            END IF;
                            v_ma_lop := v_class_id;
                        ELSE
                            SELECT MaLop, MaNV INTO v_ma_lop, v_ma_nv FROM LOP
                            WHERE MaBM = v_ma_bm AND TinhTrang = 'ChuaDay'
                            ORDER BY MaLop LIMIT 1;

                            IF v_ma_lop IS NULL THEN
                                p_result := 'ERROR';
                                p_error_msg := 'Không còn lớp trống cho bộ môn: ' || v_ma_bm;
                                RETURN;
                            END IF;
                        END IF;

                    ELSIF v_loai_dv = 'TuDo' THEN
                        NULL;
                    ELSE
                        p_result := 'ERROR';
                        p_error_msg := 'Loại dịch vụ không hợp lệ: ' || v_loai_dv;
                        RETURN;
                    END IF;

                    INSERT INTO CT_DKDV (MaCTDK, MaHD, MaDV, NgayBD, NgayKT, MaLop, MaNV)
                    VALUES (v_ma_ctdk, v_ma_hd, v_ma_dv, CURRENT_TIMESTAMP,
                            CURRENT_TIMESTAMP + (v_thoi_han || ' days')::INTERVAL,
                            v_ma_lop, v_ma_nv);

                    v_tong_tien := v_tong_tien + v_don_gia;

                    RAISE NOTICE 'Đã thêm: % (%) - Trainer: % - Lớp: %',
                        v_ma_dv, v_loai_dv, COALESCE(v_ma_nv, 'NULL'), COALESCE(v_ma_lop, 'NULL');
                END IF;
            END LOOP;

            UPDATE HOADON SET TongTien = v_tong_tien WHERE MaHD = v_ma_hd;

            p_ma_hd := v_ma_hd;
            p_tong_tien := v_tong_tien;
            p_result := 'SUCCESS';
            p_error_msg := NULL;
            EXIT;

        EXCEPTION
            WHEN unique_violation THEN
                v_retry_count := v_retry_count + 1;
                IF v_retry_count > v_max_retries THEN
                    p_result := 'ERROR';
                    p_error_msg := 'Hệ thống đang bận, vui lòng thử lại sau';
                    RETURN;
                END IF;
                PERFORM pg_sleep(0.1);
            WHEN OTHERS THEN
                p_result := 'ERROR';
                p_error_msg := 'Lỗi hệ thống: ' || SQLERRM;
                RETURN;
        END;
    END LOOP;

    IF v_retry_count > v_max_retries THEN
        p_result := 'ERROR';
        p_error_msg := 'Không thể hoàn thành đăng ký sau ' || v_max_retries || ' lần thử';
    END IF;
END;
$$;

alter function proc_dang_ky_dich_vu_universal(varchar, text, text, text, out varchar, out numeric, out varchar, out text) owner to qlyphonggym;

