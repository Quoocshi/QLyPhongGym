create function proc_cap_nhat_trainer_cho_ctdk(p_ma_ctdk character varying, p_ma_trainer character varying, OUT p_result character varying, OUT p_error_msg text) returns record
    language plpgsql
as
$$
DECLARE
    v_count INTEGER;
    v_ma_dv VARCHAR(10);
    v_ma_bm VARCHAR(10);
    v_loai_dv VARCHAR(20);
BEGIN
    SELECT COUNT(*), MAX(ct.MaDV), MAX(dv.MaBM), MAX(dv.LoaiDV)
    INTO v_count, v_ma_dv, v_ma_bm, v_loai_dv
    FROM CT_DKDV ct JOIN DICHVU dv ON ct.MaDV = dv.MaDV
    WHERE ct.MaCTDK = p_ma_ctdk;

    IF v_count = 0 THEN
        p_result := 'ERROR';
        p_error_msg := 'Không tìm thấy chi tiết đăng ký: ' || p_ma_ctdk;
        RETURN;
    END IF;

    IF v_loai_dv != 'PT' THEN
        p_result := 'ERROR';
        p_error_msg := 'Chi tiết đăng ký không phải dịch vụ PT';
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_count FROM NHANVIEN
    WHERE MaNV = p_ma_trainer AND LoaiNV = 'Trainer';
    IF v_count = 0 THEN
        p_result := 'ERROR';
        p_error_msg := 'Không tìm thấy trainer: ' || p_ma_trainer;
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_count FROM CT_CHUYENMON cm
    WHERE cm.MaNV = p_ma_trainer AND cm.MaBM = v_ma_bm;
    IF v_count = 0 THEN
        p_result := 'ERROR';
        p_error_msg := 'Trainer không có chuyên môn phù hợp';
        RETURN;
    END IF;

    UPDATE CT_DKDV SET MaNV = p_ma_trainer WHERE MaCTDK = p_ma_ctdk;

    p_result := 'SUCCESS';
    p_error_msg := NULL;
EXCEPTION
    WHEN OTHERS THEN
        p_result := 'ERROR';
        p_error_msg := 'Lỗi hệ thống: ' || SQLERRM;
END;
$$;

alter function proc_cap_nhat_trainer_cho_ctdk(varchar, varchar, out varchar, out text) owner to qlyphonggym;

