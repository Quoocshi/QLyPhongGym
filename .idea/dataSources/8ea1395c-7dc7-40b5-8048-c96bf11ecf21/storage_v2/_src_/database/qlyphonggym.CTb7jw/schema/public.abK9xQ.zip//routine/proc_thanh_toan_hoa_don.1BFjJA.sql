create function proc_thanh_toan_hoa_don(p_ma_hd character varying, OUT p_result character varying, OUT p_error_msg text) returns record
    language plpgsql
as
$$
DECLARE
    v_count INTEGER;
    v_trang_thai VARCHAR(50);
BEGIN
    SELECT COUNT(*), MAX(TrangThai) INTO v_count, v_trang_thai
    FROM HOADON WHERE MaHD = p_ma_hd;

    IF v_count = 0 THEN
        p_result := 'ERROR';
        p_error_msg := 'Không tìm thấy hóa đơn: ' || p_ma_hd;
        RETURN;
    END IF;

    IF v_trang_thai = 'DaThanhToan' THEN
        p_result := 'ERROR';
        p_error_msg := 'Hóa đơn đã được thanh toán: ' || p_ma_hd;
        RETURN;
    END IF;

    UPDATE HOADON SET TrangThai = 'DaThanhToan', NgayTT = CURRENT_TIMESTAMP
    WHERE MaHD = p_ma_hd;

    p_result := 'SUCCESS';
    p_error_msg := NULL;
EXCEPTION
    WHEN OTHERS THEN
        p_result := 'ERROR';
        p_error_msg := 'Lỗi hệ thống: ' || SQLERRM;
END;
$$;

alter function proc_thanh_toan_hoa_don(varchar, out varchar, out text) owner to qlyphonggym;

