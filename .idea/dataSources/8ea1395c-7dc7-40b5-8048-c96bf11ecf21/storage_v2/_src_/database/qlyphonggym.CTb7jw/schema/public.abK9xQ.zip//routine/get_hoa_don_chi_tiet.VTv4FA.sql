create function get_hoa_don_chi_tiet(p_ma_hd character varying)
    returns TABLE(mahd character varying, tongtien numeric, ngaylap timestamp without time zone, trangthai character varying, ngaytt timestamp without time zone, makh character varying, hoten character varying, email character varying, mactdk character varying, ngaybd timestamp without time zone, ngaykt timestamp without time zone, madv character varying, tendv character varying, dongia numeric, thoihan integer, loaidv character varying, tenbm character varying, tenlop character varying, tennhanvien character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        hd.MaHD, hd.TongTien, hd.NgayLap, hd.TrangThai, hd.NgayTT,
        kh.MaKH, kh.HoTen, kh.Email,
        ct.MaCTDK, ct.NgayBD, ct.NgayKT,
        dv.MaDV, dv.TenDV, dv.DonGia, dv.ThoiHan, dv.LoaiDV,
        bm.TenBM, l.TenLop, nv.TenNV as TenNhanVien
    FROM HOADON hd
    JOIN KHACHHANG kh ON hd.MaKH = kh.MaKH
    JOIN CT_DKDV ct ON hd.MaHD = ct.MaHD
    JOIN DICHVU dv ON ct.MaDV = dv.MaDV
    LEFT JOIN BOMON bm ON dv.MaBM = bm.MaBM
    LEFT JOIN LOP l ON ct.MaLop = l.MaLop
    LEFT JOIN NHANVIEN nv ON ct.MaNV = nv.MaNV
    WHERE hd.MaHD = p_ma_hd
    ORDER BY ct.MaCTDK;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Error in get_hoa_don_chi_tiet: %', SQLERRM;
END;
$$;

alter function get_hoa_don_chi_tiet(varchar) owner to qlyphonggym;

